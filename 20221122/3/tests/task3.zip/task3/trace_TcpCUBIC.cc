#include <iostream>
#include <fstream>
#include <string>

#include "ns3/tcp-header.h"
#include "ns3/enum.h"
#include "ns3/event-id.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/error-model.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("TcpCubicTrace");

bool firstCwnd = true;
bool firstRtt = true;
Ptr<OutputStreamWrapper> cWndStream;
Ptr<OutputStreamWrapper> rateStream;
uint32_t cWndValue;
double rttValue;


static void CwndTracer (uint32_t, uint32_t);
static void SsThreshTracer (uint32_t, uint32_t);
static void RttTracer (Time, Time);
static void TraceCwnd (std::string);
static void TraceSsThresh ();
static void TraceRtt (std::string);


int main (int argc, char *argv[])
{
  std::string transport_prot = "TcpCubic";
  double error_p = 0.0;
  std::string bandwidth = "2Mbps";
  std::string access_bandwidth = "10Mbps";
  std::string access_delay = "45ms";
  std::string cwnd_tr_file_name = "./cwnd.txt";
  std::string rate_tr_file_name = "./rate.txt";
  double data_mbytes = 0;
  uint32_t mtu_bytes = 400;
  uint16_t num_flows = 1;
  float duration = 100;
  uint32_t run = 0;
  bool flow_monitor = false;

  CommandLine cmd;
  cmd.AddValue ("error_p", "Packet error rate", error_p);
  cmd.AddValue ("bandwidth", "Bottleneck bandwidth", bandwidth);
  cmd.AddValue ("access_bandwidth", "Access link bandwidth", access_bandwidth);
  cmd.AddValue ("delay", "Access link delay", access_delay);
  cmd.AddValue ("cwnd_filename", "Name of output trace file", cwnd_tr_file_name);
  cmd.AddValue ("rate_filename", "Name of output trace file", rate_tr_file_name);
  cmd.AddValue ("data", "Number of Megabytes of data to transmit", data_mbytes);
  cmd.AddValue ("mtu", "Size of IP packets to send in bytes", mtu_bytes);
  cmd.AddValue ("duration", "Time to allow flow to run in seconds", duration);
  cmd.AddValue ("run", "Run index (for setting repeatable seeds)", run);
  cmd.AddValue ("flow_monitor", "Enable flow monitor", flow_monitor);
  cmd.Parse (argc, argv);

  SeedManager::SetSeed (1);
  SeedManager::SetRun (run);

  // Calculate the ADU size
  Header* temp_header = new Ipv4Header ();
  uint32_t ip_header = temp_header->GetSerializedSize ();
  NS_LOG_LOGIC ("IP Header size is: " << ip_header);
  delete temp_header;
  temp_header = new TcpHeader ();
  uint32_t tcp_header = temp_header->GetSerializedSize ();
  NS_LOG_LOGIC ("TCP Header size is: " << tcp_header);
  delete temp_header;
  uint32_t tcp_adu_size = mtu_bytes - (ip_header + tcp_header);
  NS_LOG_LOGIC ("TCP ADU size is: " << tcp_adu_size);

  // Set the simulation start and stop time
  float start_time = 0.1;
  float stop_time = start_time + duration;

  Config::SetDefault ("ns3::TcpL4Protocol::SocketType", TypeIdValue (TcpCubic::GetTypeId ()));

  // Create gateways, sources, and sinks
  NodeContainer gateways;
  gateways.Create (1);
  NodeContainer sources;
  sources.Create (num_flows);
  NodeContainer sinks;
  sinks.Create (num_flows);

  // Configure the error model
  // Here we use RateErrorModel with packet error rate
  Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();
  uv->SetStream (50);
  RateErrorModel error_model;
  error_model.SetRandomVariable (uv);
  error_model.SetUnit (RateErrorModel::ERROR_UNIT_PACKET);
  error_model.SetRate (error_p);

  PointToPointHelper UnReLink;
  UnReLink.SetDeviceAttribute ("DataRate", StringValue (bandwidth));
  UnReLink.SetChannelAttribute ("Delay", StringValue ("0.01ms"));
  UnReLink.SetDeviceAttribute ("ReceiveErrorModel", PointerValue (&error_model));

  InternetStackHelper stack;
  stack.InstallAll ();

  Ipv4AddressHelper address;
  address.SetBase ("10.0.0.0", "255.255.255.0");

  // Configure the sources and sinks net devices
  // and the channels between the sources/sinks and the gateways
  PointToPointHelper LocalLink;
  LocalLink.SetDeviceAttribute ("DataRate", StringValue (access_bandwidth));
  LocalLink.SetChannelAttribute ("Delay", StringValue (access_delay));
  Ipv4InterfaceContainer sink_interfaces;
  for (int i = 0; i < num_flows; i++)
    {
      NetDeviceContainer devices;
      devices = LocalLink.Install (sources.Get (i), gateways.Get (0));
      address.NewNetwork ();
      Ipv4InterfaceContainer interfaces = address.Assign (devices);
      devices = UnReLink.Install (gateways.Get (0), sinks.Get (i));
      address.NewNetwork ();
      interfaces = address.Assign (devices);
      sink_interfaces.Add (interfaces.Get (1));
    }

  NS_LOG_INFO ("Initialize Global Routing.");
  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

  uint16_t port = 50000;
  Address sinkLocalAddress (InetSocketAddress (Ipv4Address::GetAny (), port));
  PacketSinkHelper sinkHelper ("ns3::TcpSocketFactory", sinkLocalAddress);

  for (uint16_t i = 0; i < sources.GetN (); i++)
    {
      AddressValue remoteAddress (InetSocketAddress (sink_interfaces.GetAddress (i, 0), port));

      Config::SetDefault ("ns3::TcpSocket::SegmentSize", UintegerValue (tcp_adu_size));
      BulkSendHelper ftp ("ns3::TcpSocketFactory", Address ());
      ftp.SetAttribute ("Remote", remoteAddress);
      ftp.SetAttribute ("SendSize", UintegerValue (tcp_adu_size));
      ftp.SetAttribute ("MaxBytes", UintegerValue (int(data_mbytes * 1000000)));

      ApplicationContainer sourceApp = ftp.Install (sources.Get (i));
      sourceApp.Start (Seconds (start_time * i));
      sourceApp.Stop (Seconds (stop_time - 3));

      sinkHelper.SetAttribute ("Protocol", TypeIdValue (TcpSocketFactory::GetTypeId ()));
      ApplicationContainer sinkApp = sinkHelper.Install (sinks);
      sinkApp.Start (Seconds (start_time * i));
      sinkApp.Stop (Seconds (stop_time));
    }

    if (cwnd_tr_file_name.compare ("") != 0)
      {
        Simulator::Schedule (Seconds (0.00001), &TraceCwnd, cwnd_tr_file_name);
        Simulator::Schedule (Seconds (0.00001), &TraceSsThresh);
      }
    if (rate_tr_file_name.compare ("") != 0)
      {
        Simulator::Schedule (Seconds (0.00001), &TraceRtt, rate_tr_file_name);
      }

  UnReLink.EnablePcapAll ("TcpCubicTrace", true);
  LocalLink.EnablePcapAll ("TcpCubicTrace", true);

  // Flow monitor
  FlowMonitorHelper flowHelper;
  if (flow_monitor)
    {
      flowHelper.InstallAll ();
    }

  Simulator::Stop (Seconds (stop_time));
  Simulator::Run ();

  if (flow_monitor)
    {
      flowHelper.SerializeToXmlFile ("TcpCubicTrace.flowmonitor", true, true);
    }

  Simulator::Destroy ();
  return 0;
}


static void
CwndTracer (uint32_t oldval, uint32_t newval)
{
  if (firstCwnd)
    {
      *cWndStream->GetStream () << "0.0, " << oldval << std::endl;
      firstCwnd = false;
    }
  *cWndStream->GetStream () << Simulator::Now ().GetSeconds () << ", " << newval << std::endl;
  cWndValue = newval;
  
  if (!firstRtt && !firstCwnd)
    {
      *rateStream->GetStream () << Simulator::Now ().GetSeconds () << ", " << cWndValue * 8 / rttValue << std::endl;
    }
}


static void
SsThreshTracer (uint32_t oldval, uint32_t newval)
{
  if (!firstCwnd)
    {
      *cWndStream->GetStream () << Simulator::Now ().GetSeconds () << ", " << cWndValue << std::endl;
    }

  if (!firstRtt && !firstCwnd)
    {
      *rateStream->GetStream () << Simulator::Now ().GetSeconds () << ", " << cWndValue * 8 / rttValue << std::endl;
    }
}


static void
RttTracer (Time oldval, Time newval)
{
  if (firstRtt)
    {
      firstRtt = false;
    }
  rttValue = newval.GetSeconds ();
}


static void
TraceCwnd (std::string cwnd_tr_file_name)
{
  AsciiTraceHelper ascii;
  cWndStream = ascii.CreateFileStream (cwnd_tr_file_name.c_str ());
  Config::ConnectWithoutContext ("/NodeList/1/$ns3::TcpL4Protocol/SocketList/0/CongestionWindow", MakeCallback (&CwndTracer));
}


static void
TraceSsThresh ()
{
  Config::ConnectWithoutContext ("/NodeList/1/$ns3::TcpL4Protocol/SocketList/0/SlowStartThreshold", MakeCallback (&SsThreshTracer));
}


static void
TraceRtt (std::string rate_tr_file_name)
{
  AsciiTraceHelper ascii;
  rateStream = ascii.CreateFileStream (rate_tr_file_name.c_str ());
  Config::ConnectWithoutContext ("/NodeList/1/$ns3::TcpL4Protocol/SocketList/0/RTT", MakeCallback (&RttTracer));
}
