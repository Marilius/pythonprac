1) trace_TcpCUBIC.cc - программа для запуска в ./ns3
Необходимо поместить в папку scratch

Пример запуска:
/ns3 run "scratch/trace_TcpCUBIC.cc --duration=20 --cwnd_filename=./../../cwnd.txt --rate_filename=./../../rate.txt --bandwidth=2Mbps" 

Все доступные параметры можно посмотреть внутри файла

2) create_plots.py - python скрипт для создания графиков по файлам данных (адрес файлов менять внутри скрипта)