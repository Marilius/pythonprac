import pandas as pd

#read logs
cwnd_data = pd.read_csv('cwnd.txt', header=None).iloc[3:,:].reset_index(drop=True)
rate_data = pd.read_csv('rate.txt', header=None)
cwnd_data.columns = ['Time, sec', 'CWND size (bytes)']
rate_data.columns = ['Time, sec', 'Rate (bits/sec)']

# cwnd plot
cwnd_data.plot(x='Time, sec', y='CWND size (bytes)', title='CWND size', figsize=(16,10))
plt.ylabel('CWND size (bytes)')
plt.grid(True)
plt.savefig('./cwnd.png', facecolor='white')


# rate plot
rate_data.plot(x='Time, sec', y='Rate (bits/sec)', title='Rate', figsize=(16,10))
plt.ylabel('Rate (bits/sec)')
plt.grid(True)
plt.savefig('./rate.png', facecolor='white')
